/**
 * 
 */
package com.moleksyuk.chapter4.Proxy;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Jul 26, 2011
 * 
 * @author moleksyuk
 */
public interface IGraphic {

	public void draw();
}
