/**
 * 
 */
package com.moleksyuk.chapter5.AbstractFactory;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Jul 27, 2011
 * 
 * @author moleksyuk
 */
public class CPU_x86 implements CPU {

}
