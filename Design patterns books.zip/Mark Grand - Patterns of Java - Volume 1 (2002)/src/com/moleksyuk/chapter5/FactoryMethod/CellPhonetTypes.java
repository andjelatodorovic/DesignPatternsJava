package com.moleksyuk.chapter5.FactoryMethod;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 2, 2011
 * 
 * @author moleksyuk
 */
public enum CellPhonetTypes {
	HTC, IPHONE, SAMSUNG
}
