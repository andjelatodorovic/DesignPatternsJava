package com.moleksyuk.chapter5.FactoryMethod;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Jul 26, 2011
 * 
 * @author moleksyuk
 */
public interface ICellPhone {

}
