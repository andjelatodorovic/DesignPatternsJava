/**
 * 
 */
package com.moleksyuk.chapter6.Composite;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 5, 2011
 * 
 * @author moleksyuk
 */
public class Page extends CompositeDocumentElement {

}
