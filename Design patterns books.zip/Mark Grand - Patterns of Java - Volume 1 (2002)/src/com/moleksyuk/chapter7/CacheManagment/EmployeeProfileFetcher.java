package com.moleksyuk.chapter7.CacheManagment;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 11, 2011
 * 
 * @author moleksyuk
 */
public class EmployeeProfileFetcher {

	public EmployeeProfile fetchEmployee(EmployeeID id) {
		// TODO Auto-generated method stub
		return null;
	}

}
