package com.moleksyuk.chapter7.Flyweight;

public abstract class DocumentElement {

}
