/**
 * 
 */
package com.moleksyuk.chapter9.AsynchronousProcessing;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 23, 2011
 * 
 * @author moleksyuk
 */
public class Main {

	public static void main(String[] args) {
		CancelFrame window = new CancelFrame();
		window.setVisible(true);
	}

}
