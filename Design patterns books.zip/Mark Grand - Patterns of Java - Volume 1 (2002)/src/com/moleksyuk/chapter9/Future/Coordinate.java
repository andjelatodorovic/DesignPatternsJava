/**
 * 
 */
package com.moleksyuk.chapter9.Future;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 22, 2011
 * 
 * @author moleksyuk
 */
public class Coordinate {

}
