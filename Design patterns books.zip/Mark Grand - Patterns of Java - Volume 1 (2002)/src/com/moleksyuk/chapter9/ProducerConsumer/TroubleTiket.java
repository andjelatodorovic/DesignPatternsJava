/**
 * 
 */
package com.moleksyuk.chapter9.ProducerConsumer;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 19, 2011
 * 
 * @author moleksyuk
 */
public class TroubleTiket {

}
