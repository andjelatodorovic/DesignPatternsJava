/**
 * 
 */
package com.moleksyuk.chapter9.TwoPhaseTermination;

import java.net.Socket;

/**
 * Based on: "Patterns in Java", Mark Grand.
 * 
 * Date: Aug 19, 2011
 * 
 * @author moleksyuk
 */
public class Portfolio {

	public void sendTransactionsToClient(Socket mySocket) {
		// TODO Auto-generated method stub

	}

}
